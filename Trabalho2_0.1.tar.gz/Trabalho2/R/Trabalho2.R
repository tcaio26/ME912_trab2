#' @name Trabalho2
#'
#' @docType package
#'
#' @description
#' Um pacote para aplicar e avaliar modelos de regressão linear, com dados de exemplo
#' @export
"_PACKAGE"
